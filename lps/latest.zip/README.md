#Responsive Navbar with Angular Material and Angular Flex Layout.

The demo for this repo can be found [here](https://mainawycliffe.github.io/Responsive-Navbar-with-Angular-Material-and-Angular-Flex-Layout/)

Find the full explanation of this demo [here](https://theinfogrid.com/tech/developers/angular/responsive-navbar-angular-flex-layout/)
