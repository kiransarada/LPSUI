import { TablesearchPipe } from './tablesearch.pipe';

describe('TablesearchPipe', () => {
  it('create an instance', () => {
    const pipe = new TablesearchPipe();
    expect(pipe).toBeTruthy();
  });
});
