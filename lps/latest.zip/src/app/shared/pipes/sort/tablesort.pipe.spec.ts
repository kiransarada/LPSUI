import { TablesortPipe } from './tablesort.pipe';

describe('TablesortPipe', () => {
  it('create an instance', () => {
    const pipe = new TablesortPipe();
    expect(pipe).toBeTruthy();
  });
});
