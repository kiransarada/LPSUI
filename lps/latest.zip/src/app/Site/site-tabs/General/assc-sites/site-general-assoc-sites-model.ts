export interface SiteAssociatedSites {
    siteUsid: string;
    siteName:  string;
    status: string;
    masterSite: string;
    FANumber: string;
}
