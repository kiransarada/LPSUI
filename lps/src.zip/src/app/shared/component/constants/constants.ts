export const Constants = {
    RECORDSPERPAGE:50
  };