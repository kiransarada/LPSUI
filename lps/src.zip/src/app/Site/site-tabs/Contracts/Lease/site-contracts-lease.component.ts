import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-contracts-lease',
  templateUrl: './site-contracts-lease.component.html',
  styleUrls: ['./site-contracts-lease.component.css']
})
export class SiteContractsLeaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
