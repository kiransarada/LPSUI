export interface SiteLinkToFilenet {
    filenetDoc: string;
}
