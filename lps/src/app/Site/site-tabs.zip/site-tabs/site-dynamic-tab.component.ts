import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { DataService } from 'src/app/shared/services/data.service';

@Component({
  selector: 'app-site-dynamic-tab',
  templateUrl: './site-dynamic-tab.component.html',
  styleUrls: ['./site-dynamic-tab.component.css']
})
export class SiteDynamicTabComponent implements OnInit, AfterViewInit {
  @Input() parentJson;
  @Input() tab;
  sectionData: any;
  isTable: boolean;
  left: any;
  right: any;
  section: string;
  label: any;
  data: any;
  url: any;
  oneSidedSection: any;
  showFlag: Boolean = true;
  present: string = "show more";
  newShowData:any;
  showMore1:any;
  showMore2:any;
  leftSiteModal : any;
  sectionUrl: any;
  //parentJson : any;
  constructor(private dataService: DataService) { }
  ngOnInit() {
    this.getSectionData(this.parentJson.section);
    this.section = this.parentJson.section;
    this.section = this.tab.key;
    
  }
  ngAfterViewInit() {
  }
  fetchSiteInfo(popover, type, value) {
    this.url='http://localhost:12234/LeaseBasicUIService/lease/sitedetails';
    this.getData(this.url, popover);
  }
  getData(url, popover) {
   
    this.dataService.getGeneralPopup(url)
      .subscribe(response => {       
        this.leftSiteModal = response['data'];       
      },
        (error: any) => {
          console.log('error', error);
        });
  }

 

  show() {
    let url = 'http://localhost:12234/LeaseBasicUIService/lease/showmoregeneral';
    this.showFlag = !this.showFlag;
    if (!this.showFlag) {
      this.dataService.getShowMoreGeneral(url)
      .subscribe((res) => {
        console.log("show res",res);
        let halflength = Math.ceil(res['data'].length/2);
          let arr1 =res['data'].slice(0,halflength);
          let arr2 =res['data'].slice(halflength,res['data'].length);
          this.showMore1 = arr1; 
          this.showMore2 = arr2;     
        this.present = "show less";

      })
     
    }
    else {
      this.present = "show more";
    }
  }
  getSectionData(response) {
      if(response == 'general'){
        this.sectionUrl = 'http://localhost:12234/LeaseBasicUIService/lease/general';
      }else if(response == 'managementCompany'){
        this.sectionUrl = 'http://localhost:12234/LeaseBasicUIService/lease/managementcompany';
      }else if(response == 'assetLesseeandLessorDetails'){
        this.sectionUrl = 'http://localhost:12233/LeaseContactUIService/lessee/lessor';
      }else if(response == 'contactLookup'){
        this.sectionUrl = 'http://localhost:12233/LeaseContactUIService/contact/otherinfo';
      }else if(response == 'lesseeAssignment'){
        this.sectionUrl = 'http://localhost:12234/LeaseBasicUIService/lease/lesseeassignment';
      }else if(response == 'lessorAssignment'){
        this.sectionUrl = 'http://localhost:12234/LeaseBasicUIService/lease/lessorassignment';
      }else if(response == 'criticalDates'){
        this.sectionUrl = 'http://localhost:12234/LeaseBasicUIService/lease/criticaldate';
      }else if(response == 'moreDetails'){
        this.sectionUrl = 'http://localhost:12271/LeaseMoreUIService/lease/details';
      }else if(response == 'notes'){
        this.sectionUrl = 'http://localhost:12271/LeaseMoreUIService/lease/Notes';
      }else if(response == 'mla'){
        this.sectionUrl = 'http://localhost:12271/LeaseMoreUIService/lease/mla';
      }else if(response == 'contractManager'){
        this.sectionUrl = 'http://localhost:12233/LeaseContactUIService/contract/manager';
      }else if(response == 'revisionHistory'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/revisionHistory';
      }else if(response == 'amendmentHistory'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/amendmentHistory';
      }else if(response == 'faChangeAudit'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/fachangeAudit';
      }else if(response == 'mlaAssociationAudit'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/mlaAssociation';
      }else if(response == 'mlaApplyTemplateAudit'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/mlaTemplateAudit';
      }else if(response == 'unretireAudit'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/unretiredAudit';
      }else if(response == 'terminationAudit'){
        this.sectionUrl = 'http://localhost:12288/LeaseAuditUIService/audit/terminationAudit';
      }
      
      this.dataService.getSectionData(this.sectionUrl, response)
    .subscribe(sectionResponse => {
    this.sectionData = sectionResponse; 
    console.log(this.sectionData);
    this.oneSidedSection = this.sectionData.data;
    console.log("section data", this.sectionData)
    console.log(this.sectionData.data);
    this.isTable = this.sectionData.isTable;

    if (!this.isTable) {
      const half = Math.ceil(this.sectionData.data.length / 2);
      // console.log(half+"^^^^^^^^^^^^^^^^^^^^^^^^^^^");
      this.left = JSON.stringify(this.sectionData.data);
      this.left = JSON.parse(this.left);
      console.log("left data:", this.left)
      this.right = JSON.stringify(this.sectionData.data);
      this.right = JSON.parse(this.right);
      this.left = this.left.splice(0, half);
      this.right = this.right.splice(half, this.sectionData.data.length - half);
    } else if (this.isTable && this.section === 'amendmentHistory') {
        this.label = this.sectionData.labels;
        this.data = this.sectionData.data;
        // console.log(this.sectionData.labels);
        // console.log(this.sectionData.section.data);
    } else if (this.isTable && this.section === 'contactsLookup') {
        this.label = this.sectionData.labels;
        this.data = this.sectionData.data;
        console.log(this.sectionData.labels);
        console.log(this.sectionData.data);
    } else {
      
        this.label = this.sectionData.labels;
        this.data = this.sectionData.data;
         console.log(this.label);
         console.log(this.data);
    }
  });
    // console.log(JSON.stringify(this.generalJSOn));
    // },
    //   (error: any) => {
    //     console.log('error', error);
    //   });
  }

  // fetchContent(path) {
  //   console.log(this.sectionData+'line 90.........');
  //   this.dataService.getSectionData(this.accUrl)
  //     .subscribe((section) => {        
  //      // this.sections =data;
  //      this.sectionData = {
  //       'path': path,
  //       'section': section
  //     };
  //      console.log(this.sectionData);
  //     },
  //     (error: any) => {
  //       console.log('error', error);
  //     });

  // }


}

