export interface Table {
    id: Number;
    faNo: Number;
    siteName: String;
    siteUsid: Number;
    market: String;
    leaseStatus: String;
}
