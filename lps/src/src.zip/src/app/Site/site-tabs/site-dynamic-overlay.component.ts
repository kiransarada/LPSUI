import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../../shared/services/data.service';
import { SiteDynamicTabComponent } from '../../Site/site-tabs/site-dynamic-tab.component';

@Component({
  selector: 'app-site-dynamic-overlay',
  templateUrl: './site-dynamic-overlay.component.html',
  styleUrls: ['./site-dynamic-overlay.component.css']
})
export class SiteDynamicOverlayComponent implements OnInit {
  public isCollapsed = false;
  @ViewChild(SiteDynamicTabComponent) private overLayChild: SiteDynamicTabComponent;
  tabs: any;
  sections: any;
  path: any;
  sectionData:any =[];
  data= false
  tab : any;
  section :any;
  url:any;
  agreementId  : any;

  constructor(private dataService: DataService) { }
  ngOnInit() {
  }

  
  showConfig(response, agreeId) {
   console.log(this.overLayChild);

      this.url=`http://130.6.149.41:5102/LeaseMoreUIService/lease/getSection`;

      // this.overLayChild.setAgreementIDNew(agreeId);
      this.agreementId = agreeId;
      this.dataService.getSectionPost(this.url,response, agreeId).subscribe((data)=> {

      // this.dataService.getConfig(url)
      // .subscribe((data) => {
        console.log(data);        
        this.tabs = data['data'];     
       },
      (error: any) => {
        console.log('error', error);
      });
  }
  fetchContent(section,i,agreementID) {
    // console.log(section,i);
    this.data =false;
    // console.log("FetchContent",section)
   // this.path = 'assets/JSON/' + section + '.json';

   this.section = section;
   this.sectionData = {
    'path': this.path,
    'section': section ,
    'agreementID': agreementID 
  }
   
    
  }


  

}
