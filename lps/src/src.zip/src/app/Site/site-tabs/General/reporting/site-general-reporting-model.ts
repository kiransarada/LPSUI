export interface SiteReporting {
    settlementCompany: string;
    proceedWithSettlement: boolean;
    additionToPay: boolean;
    dealRelated: boolean;
}
